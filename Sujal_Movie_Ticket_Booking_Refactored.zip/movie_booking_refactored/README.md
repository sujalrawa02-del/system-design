# Cinema Ticket Booking System

A C++ OOP console application for browsing movies, selecting shows and seats, processing payments, searching tickets, and cancelling bookings.

## Build

```bash
g++ -std=c++17 src/main.cpp -o movie_booking
```

Run with:

```bash
./movie_booking
```

## Main OOP ideas
- Encapsulation: Movie, Seat, Screen, Show and Booking keep their data private.
- Inheritance / Polymorphism: PaymentMethod has UPI, Card and Cash implementations.
- Composition: Shows contain a Screen; screens contain Seats.
- Abstraction: BookingSystem coordinates the application workflow.

## Features
1. View movie catalogue
2. Select a show
3. Display live seat status for the running program
4. Select multiple seats
5. Calculate price by seat category
6. Pay using UPI, card or cash
7. Generate a ticket ID
8. Search ticket by ID or phone
9. Cancel a ticket
