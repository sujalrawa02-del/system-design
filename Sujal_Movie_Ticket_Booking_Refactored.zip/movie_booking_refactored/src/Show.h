#ifndef SHOW_H
#define SHOW_H
#include <string>
#include <iostream>
#include <vector>
#include "Movie.h"
#include "Screen.h"
class Show {
    int id; Movie movie; Screen screen; std::string time;
public:
    Show(int i, const Movie& m, const Screen& s, std::string t): id(i), movie(m), screen(s), time(t) {}
    int getId() const{return id;}
    const Movie& getMovie() const{return movie;}
    const Screen& getScreen() const{return screen;}
    Screen& accessScreen(){return screen;}
    const std::string& getTime() const{return time;}
    void printSeats() const{
        std::cout << "\n" << movie.getTitle() << " | " << screen.getName() << " | " << time << "\n";
        for(const auto& s:screen.getSeats()) std::cout << s.getCode() << (s.available()?"[ ] ":"[X] ");
        std::cout << "\n[ ] Available   [X] Booked\n";
    }
};
#endif
