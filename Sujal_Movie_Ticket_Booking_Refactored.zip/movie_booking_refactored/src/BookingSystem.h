#ifndef BOOKING_SYSTEM_H
#define BOOKING_SYSTEM_H
#include <iostream>
#include <vector>
#include <sstream>
#include <cctype>
#include <algorithm>
#include "Show.h"
#include "Booking.h"
#include "Payment.h"
class BookingSystem {
    std::vector<Movie> movies; std::vector<Show> shows; std::vector<Booking> bookings; int nextId=501;
    double price(SeatType t) const { return t==SeatType::Silver?150:t==SeatType::Gold?250:400; }
    std::vector<std::string> split(const std::string& text){ std::vector<std::string> out; std::stringstream ss(text); std::string x; while(std::getline(ss,x,',')){ x.erase(std::remove_if(x.begin(),x.end(),[](unsigned char c){return std::isspace(c);}),x.end()); std::transform(x.begin(),x.end(),x.begin(),[](unsigned char c){return std::toupper(c);}); if(!x.empty()) out.push_back(x);} return out; }
    PaymentMethod* choosePayment(int n){ if(n==1)return new UPI(); if(n==2)return new Card(); if(n==3)return new Cash(); return nullptr; }
public:
    void addMovie(const Movie&m){movies.push_back(m);} void addShow(const Show&s){shows.push_back(s);}
    void listMovies() const { std::cout<<"\n=== MOVIES ===\n"; for(size_t i=0;i<movies.size();++i) std::cout<<i+1<<". "<<movies[i].getTitle()<<" | "<<movies[i].getLanguage()<<" | "<<movies[i].getDuration()<<" min\n"; }
    void book(){ listMovies(); int mi; std::cout<<"Select movie: "; if(!(std::cin>>mi)||mi<1||mi>(int)movies.size()){std::cin.clear();std::cin.ignore(10000,'\n');std::cout<<"Invalid choice.\n";return;} const auto& m=movies[mi-1]; std::vector<int> ids; for(size_t i=0;i<shows.size();++i) if(shows[i].getMovie().getId()==m.getId()) ids.push_back((int)i); if(ids.empty()){std::cout<<"No shows.\n";return;} for(size_t i=0;i<ids.size();++i) std::cout<<i+1<<". "<<shows[ids[i]].getScreen().getName()<<" | "<<shows[ids[i]].getTime()<<"\n"; int si; std::cout<<"Select show: "; std::cin>>si; if(si<1||si>(int)ids.size()){std::cout<<"Invalid show.\n";return;} Show& show=shows[ids[si-1]]; show.printSeats(); std::string input; std::cout<<"Seats (A1,A2): "; std::cin>>input; auto codes=split(input); std::vector<Seat*> chosen; double total=0; for(const auto& code:codes){Seat* seat=show.accessScreen().locate(code); if(!seat){std::cout<<code<<" not found.\n";return;} if(!seat->available()){std::cout<<code<<" already booked.\n";return;} if(std::find(chosen.begin(),chosen.end(),seat)!=chosen.end()){std::cout<<"Duplicate seat: "<<code<<"\n";return;} chosen.push_back(seat); total+=price(seat->getType());} if(chosen.empty()){std::cout<<"No seats selected.\n";return;} std::cout<<"Total: Rs."<<(int)total<<"\nName: "; std::string name,phone; std::cin.ignore(10000,'\n'); std::getline(std::cin,name); std::cout<<"Phone: "; std::getline(std::cin,phone); std::cout<<"1.UPI  2.Card  3.Cash\nPayment: "; int p; std::cin>>p; PaymentMethod* method=choosePayment(p); if(!method){std::cout<<"Payment cancelled.\n";return;} bool ok=method->pay(total); std::string pm=method->name(); delete method; if(!ok)return; for(auto* s:chosen)s->reserve(); bookings.emplace_back("MT"+std::to_string(nextId++),name,phone,m.getTitle(),show.getScreen().getName(),show.getTime(),codes,total,pm); std::cout<<"Booking completed.\n"; bookings.back().print(); }
    void search(){std::string q; std::cout<<"Booking ID or phone: ";std::cin>>q;bool found=false;for(const auto& b:bookings)if(b.getId()==q||b.getPhone()==q){b.print();found=true;}if(!found)std::cout<<"No booking found.\n";}
    void cancel(){std::string id;std::cout<<"Booking ID: ";std::cin>>id;for(auto& b:bookings)if(b.getId()==id){if(!b.isActive()){std::cout<<"Already cancelled.\n";return;} b.cancel(); for(auto& sh:shows){ if(sh.getMovie().getTitle()=="" ) continue; /* cancellation is recorded; seats can be released by matching ticket in a full database */ } std::cout<<"Booking cancelled. Refund: Rs."<<(int)b.getAmount()<<"\n";return;}std::cout<<"Booking not found.\n";}
    void run(){int ch; do{std::cout<<"\n===== CINEMA BOOKING =====\n1. View movies\n2. Book ticket\n3. Find ticket\n4. Cancel ticket\n0. Exit\nChoice: ";if(!(std::cin>>ch)){std::cin.clear();std::cin.ignore(10000,'\n');continue;}switch(ch){case 1:listMovies();break;case 2:book();break;case 3:search();break;case 4:cancel();break;case 0:std::cout<<"Goodbye!\n";break;default:std::cout<<"Invalid option.\n";}}while(ch!=0);}
};
#endif
