#ifndef SEAT_H
#define SEAT_H
#include <string>
enum class SeatType { Silver, Gold, Platinum };
class Seat {
    std::string code; SeatType type; bool booked;
public:
    Seat(std::string c="", SeatType t=SeatType::Silver): code(c), type(t), booked(false) {}
    const std::string& getCode() const { return code; }
    SeatType getType() const { return type; }
    bool available() const { return !booked; }
    void reserve() { booked=true; }
    void release() { booked=false; }
    static std::string typeName(SeatType t) { return t==SeatType::Silver?"SILVER":t==SeatType::Gold?"GOLD":"PLATINUM"; }
};
#endif
