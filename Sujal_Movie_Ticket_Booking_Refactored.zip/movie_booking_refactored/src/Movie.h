#ifndef MOVIE_H
#define MOVIE_H
#include <string>
class Movie {
    int id; std::string title, language; int duration;
public:
    Movie(int i=0, std::string t="", std::string l="English", int d=0): id(i), title(t), language(l), duration(d) {}
    int getId() const { return id; }
    const std::string& getTitle() const { return title; }
    const std::string& getLanguage() const { return language; }
    int getDuration() const { return duration; }
};
#endif
