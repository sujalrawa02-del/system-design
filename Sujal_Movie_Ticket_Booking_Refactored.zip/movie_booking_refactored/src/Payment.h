#ifndef PAYMENT_H
#define PAYMENT_H
#include <string>
#include <iostream>
class PaymentMethod { public: virtual ~PaymentMethod()=default; virtual bool pay(double)=0; virtual std::string name() const=0; };
class UPI final: public PaymentMethod { public: bool pay(double amount) override { std::cout<<"UPI payment successful: Rs."<<(int)amount<<"\n"; return true; } std::string name() const override{return "UPI";} };
class Card final: public PaymentMethod { public: bool pay(double amount) override { std::cout<<"Card payment successful: Rs."<<(int)amount<<"\n"; return true; } std::string name() const override{return "Card";} };
class Cash final: public PaymentMethod { public: bool pay(double amount) override { std::cout<<"Cash payment received: Rs."<<(int)amount<<"\n"; return true; } std::string name() const override{return "Cash";} };
#endif
