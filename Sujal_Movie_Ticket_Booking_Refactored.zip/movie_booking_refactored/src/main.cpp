#include "BookingSystem.h"
int main(){
    Screen s1(1,"Screen A");
    for(const char* c:{"A1","A2","A3","A4"}) s1.addSeat(Seat(c,SeatType::Silver));
    for(const char* c:{"B1","B2","B3"}) s1.addSeat(Seat(c,SeatType::Gold));
    for(const char* c:{"C1","C2"}) s1.addSeat(Seat(c,SeatType::Platinum));
    Screen s2(2,"Screen B");
    for(const char* c:{"A1","A2","A3"}) s2.addSeat(Seat(c,SeatType::Silver));
    for(const char* c:{"B1","B2"}) s2.addSeat(Seat(c,SeatType::Gold));
    for(const char* c:{"C1","C2"}) s2.addSeat(Seat(c,SeatType::Platinum));
    Movie m1(11,"3 Idiots","Hindi",170), m2(12,"Interstellar","English",169), m3(13,"Dangal","Hindi",161);
    BookingSystem system;
    system.addMovie(m1);system.addMovie(m2);system.addMovie(m3);
    system.addShow(Show(201,m1,s1,"06:00 PM"));
    system.addShow(Show(202,m1,s2,"09:00 PM"));
    system.addShow(Show(203,m2,s1,"09:30 PM"));
    system.addShow(Show(204,m3,s2,"04:30 PM"));
    system.run();
    return 0;
}
