#ifndef BOOKING_H
#define BOOKING_H
#include <string>
#include <iostream>
#include <vector>
class Booking {
    std::string id, customer, phone, movie, screen, time, payment; std::vector<std::string> seats; double amount; bool active;
public:
    Booking(std::string i,std::string c,std::string p,std::string m,std::string s,std::string t,std::vector<std::string> ss,double a,std::string pm)
      :id(i),customer(c),phone(p),movie(m),screen(s),time(t),seats(ss),amount(a),payment(pm),active(true){}
    const std::string& getId()const{return id;} const std::string& getPhone()const{return phone;} bool isActive()const{return active;} double getAmount()const{return amount;}
    void cancel(){active=false;}
    void print()const{ std::cout<<"\n--- TICKET ---\nID: "<<id<<"\nName: "<<customer<<"\nPhone: "<<phone<<"\nMovie: "<<movie<<"\nScreen: "<<screen<<"\nTime: "<<time<<"\nSeats: "; for(size_t i=0;i<seats.size();++i) std::cout<<seats[i]<<(i+1<seats.size()?", ":""); std::cout<<"\nAmount: Rs."<<(int)amount<<"\nPayment: "<<payment<<"\nStatus: "<<(active?"CONFIRMED":"CANCELLED")<<"\n--------------\n"; }
};
#endif
