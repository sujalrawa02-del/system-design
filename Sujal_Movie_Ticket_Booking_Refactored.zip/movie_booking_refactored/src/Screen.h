#ifndef SCREEN_H
#define SCREEN_H
#include <vector>
#include <string>
#include "Seat.h"
class Screen {
    int number; std::string name; std::vector<Seat> seats;
public:
    Screen(int n=0, std::string s=""): number(n), name(s) {}
    void addSeat(const Seat& s){ seats.push_back(s); }
    int getNumber() const { return number; }
    const std::string& getName() const { return name; }
    std::vector<Seat>& getSeats(){ return seats; }
    const std::vector<Seat>& getSeats() const { return seats; }
    Seat* locate(const std::string& code){ for(auto& s:seats) if(s.getCode()==code) return &s; return nullptr; }
};
#endif
